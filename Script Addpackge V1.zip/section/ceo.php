            <tr>
                <td id="cpanelmini" style="padding:5px;font-size:15px;font-weight: bold;color:#017bff"><i class="fa fa-circle"></i> CPANEL MINI</td>
                <td id="whmmini" style="padding:5px;font-size:15px;font-weight: bold;color:#017bff"><i class="fa fa-circle"></i> WHM MINI</td>
                <td id="mwhmmini" style="padding:5px;font-size:15px;font-weight: bold;color:#017bff"><i class="fa fa-circle"></i> MWHM MINI</td>
            </tr>
            <tr>
                <td id="cpanelmedium" style="padding:5px;font-size:15px;font-weight: bold;color:#017bff"><i class="fa fa-circle"></i> CPANEL MEDIUM</td>
                <td id="whmmedium" style="padding:5px;font-size:15px;font-weight: bold;color:#017bff"><i class="fa fa-circle"></i> WHM MEDIUM</td>
                <td id="mwhmmedium" style="padding:5px;font-size:15px;font-weight: bold;color:#017bff"><i class="fa fa-circle"></i> MWHM MEDIUM</td>
            </tr>
            <tr>
                <td id="cpanelextra" style="padding:5px;font-size:15px;font-weight: bold;color:#017bff"><i class="fa fa-circle"></i> CPANEL EXTRA</td>
                <td id="whmextra" style="padding:5px;font-size:15px;font-weight: bold;color:#017bff"><i class="fa fa-circle"></i> WHM EXTRA</td>
                <td id="mwhmextra" style="padding:5px;font-size:15px;font-weight: bold;color:#017bff"><i class="fa fa-circle"></i> MWHM EXTRA</td>
            </tr>
            <tr>
                <td id="cpanelsuper" style="padding:5px;font-size:15px;font-weight: bold;color:#017bff"><i class="fa fa-circle"></i> CPANEL SUPER</td>
                <td id="whmsuper" style="padding:5px;font-size:15px;font-weight: bold;color:#017bff"><i class="fa fa-circle"></i> WHM SUPER</td>
                <td id="mwhmsuper" style="padding:5px;font-size:15px;font-weight: bold;color:#017bff"><i class="fa fa-circle"></i> MWHM SUPER</td>
            </tr>
            <tr>
                <td id="admin" style="padding:5px;font-size:15px;font-weight: bold;color:#017bff"><i class="fa fa-circle"></i> ADMIN</td>
            </tr>