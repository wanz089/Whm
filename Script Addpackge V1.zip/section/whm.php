			<tr>
                <td id="cpanelmini" style="padding:5px;font-size:15px;font-weight: bold;color:#017bff"><i class="fa fa-circle"></i> CPANEL MINI</td>
            </tr>
            <tr>
                <td id="cpanelmedium" style="padding:5px;font-size:15px;font-weight: bold;color:#017bff"><i class="fa fa-circle"></i> CPANEL MEDIUM</td>
            </tr>
            <tr>
                <td id="cpanelextra" style="padding:5px;font-size:15px;font-weight: bold;color:#017bff"><i class="fa fa-circle"></i> CPANEL EXTRA</td>
            </tr>
            <tr>
                <td id="cpanelsuper" style="padding:5px;font-size:15px;font-weight: bold;color:#017bff"><i class="fa fa-circle"></i> CPANEL SUPER</td>
            </tr>